import streamlit as st
import pandas as pd
from src import config
from src.postgresql import crud


import streamlit as st
import pandas as pd
from main import Session


def edit_condition_db(*args):
    columns = [
        "id",
        "select_condition",
        "ignore_elements",
        "corrosive_active_elements",
        "difficult_condition",
        "content_in_spectrum",
        "number_of_spectors",
        "joint_finding",
        "conditions_of_joint_residence",
        "place_of_origin",
    ]

    # Преобразуйте списки в строки
    data = {
        col: ",".join(val) if isinstance(val, list) else val
        for col, val in zip(columns, args)
    }
    session = Session()
    crud.update_conditions(session, data)
    session.close()


@st.dialog("Новое место возникновения")
def vote():
    reason = st.text_input("Новое место возникновения")
    if st.button("Добавить"):
        if reason != "":
            if reason not in st.session_state.all_places_of_origin:
                session = Session()
                crud.create_place(session, reason)
                session.close()
                load_data()
                st.rerun()
            else:
                st.error("Такое место возникновения уже есть")

        else:
            st.error("Укажите новое место возникновения")


@st.dialog("Редактировать условие")
def edit_condition():
    selected_data = st.session_state.data.loc[
        st.session_state.data_new["Выбрать"] == True
    ]
    if len(selected_data) == 0:
        st.error("Выберете условие, которое хотите редактировать.")

    elif len(selected_data) > 1:
        st.error("Выберете 1 условие, которое хотите редактировать.")

    else:

        corrosively_active_elements = st.multiselect(
            "Коррозинно активные элементы",
            options=config.elements,
            default=selected_data["Коррозинно активные элементы"].values[0].split(","),
            key="edit_condition_corrosively_active_elements",
        )
        # Содержание в спектре
        st.markdown("###### Содержание в спектре")
        difficult_condition = st.toggle(
            "Сложное условие",
            value=selected_data["Сложное условие"].values[0],
            key="edit_condition_difficult_condition",
        )
        if st.session_state.ignore_elements == "менее 1%":
            min_value = 1.0
            max_value = None
        else:
            min_value = 0.5
            max_value = 0.99
        if difficult_condition:
            content_spectrum_all = st.number_input(
                "Каждый из элементов",
                min_value=min_value,
                max_value=max_value,
                key="edit_condition_spectrum_all",
            )
            st.text("или")
            col1, col2 = st.columns(2)
            content_spectrum_2_3 = col1.number_input(
                "Два из трех",
                min_value=min_value,
                max_value=max_value,
                key="edit_condition_spectrum_2_3",
            )
            content_spectrum_3 = col2.number_input(
                "Третий",
                min_value=min_value,
                max_value=max_value,
                key="edit_condition_content_spectrum_3",
            )
            content_spectrum = f">={content_spectrum_all}% каждый из элементов или >={content_spectrum_2_3}% два из трех и >={content_spectrum_3}% третий"
        else:
            content_spectrum = st.number_input(
                "Каждый из элементов",
                min_value=min_value,
                max_value=max_value,
                key="edit_condition_content_spectrum",
            )
        # Количество спекторов
        st.markdown("###### Количество спекторов")

        number_spectra = st.number_input(
            "Количество спекторов",
            label_visibility="hidden",
            value=int(selected_data["Количество спекторов"].values),
            key="edit_condition_number_spectra",
        )
        # Совместное нахождение
        st.markdown("###### Совместное нахождение")
        if selected_data["Совместное нахождение"].values[0]:
            joint_finding = st.multiselect(
                "Совместное нахождение",
                options=config.elements,
                label_visibility="hidden",
                default=selected_data["Совместное нахождение"].values[0].split(","),
                key="edit_condition_joint_finding",
            )
        else:
            joint_finding = st.multiselect(
                "Совместное нахождение",
                options=config.elements,
                label_visibility="hidden",
                key="edit_condition_joint_finding",
            )
        # Условия совместного нахождения
        st.markdown("###### Условия совместного нахождения")
        st.text("Условия совместного нахождения")
        options = [
            ">1% одном спектре не совместно",
            "любые в любом сочетании >=1%",
            "основные >1%, остальные <1%",  # Новая опция
            "один элемент 1-5% без других >1%",  # Новая опция
            "Нет условия",
        ]
        conditions_joint_residence = st.selectbox(
            "Условия совместного нахождения",
            options=options,
            index=options.index(
                selected_data["Условия совместного нахождения"].values[0]
            ),
            label_visibility="hidden",
            key="edit_condition_joint_residence",
        )
        # Место возникновения
        st.markdown("###### Место возникновения")
        place_origin = st.selectbox(
            "Место возникновения",
            st.session_state.all_places_of_origin,
            index=st.session_state.all_places_of_origin.index(
                selected_data["Место возникновения"].values[0]
            ),
            label_visibility="hidden",
            key="edit_condition_place_origin",
        )
        if st.button(
            "Обновить",
            on_click=edit_condition_db,
            args=(
                selected_data["id"].values[0],
                False,
                "менее 1%",
                corrosively_active_elements,
                difficult_condition,
                content_spectrum,
                number_spectra,
                joint_finding,
                conditions_joint_residence,
                place_origin,
            ),
        ):
            load_data()
            st.rerun()


def delete_lines():
    selected_data = st.session_state.data.loc[
        st.session_state.data_new["Выбрать"] == True
    ]
    if len(selected_data) == 0:
        tab1.error("Выберете условие, которое хотите удалить.")
        return
    session = Session()
    for index, row in selected_data.iterrows():
        crud.delete_condition(session, row["id"])
    session.close()
    load_data()


def delete_lines_final_result():
    selected_data = st.session_state.final_result_all.loc[
        st.session_state.final_result_all_new["Выбрать"] == True
    ]
    if len(selected_data) == 0:
        tab2.warning("Выберете условие, которое хотите удалить.")
        return
    session = Session()
    for index, row in selected_data.iterrows():
        crud.delete_final_result(session, index)
    session.close()
    load_data()


def add_condition(*args):
    columns = [
        "select_condition",
        "ignore_elements",
        "corrosive_active_elements",
        "difficult_condition",
        "content_in_spectrum",
        "number_of_spectors",
        "joint_finding",
        "conditions_of_joint_residence",
        "place_of_origin",
    ]

    # Преобразуйте списки в строки
    data = {
        col: ",".join(val) if isinstance(val, list) else val
        for col, val in zip(columns, args)
    }

    session = Session()
    crud.create_analysis_with_place(session, data)
    session.close()
    load_data()


def load_data():
    session = Session()
    st.session_state.data = pd.DataFrame(crud.get_all_analysis_with_places(session))
    st.session_state.final_result_all = pd.DataFrame(
        crud.get_all_final_results(session)
    )

    if st.session_state.final_result_all.shape != (0, 0):
        st.session_state.final_result_all.set_index("id", inplace=True)
    st.session_state.all_places_of_origin = crud.get_all_places_of_origin(session)
    session.close()


# Проверка, была ли уже загружена база данных
if "data" not in st.session_state:
    load_data()

tab1, tab2 = st.tabs(["Условия", "Итог"])
tab1.markdown("## Условия")

st.session_state.data_new = tab1.data_editor(
    st.session_state.data,
    disabled=[
        "id",
        "Не учитывать элементы",
        "Коррозинно активные элементы",
        "Сложное условие",
        "Содержание в спектре",
        "Количество спекторов",
        "Совместное нахождение",
        "Условия совместного нахождения",
        "Место возникновения",
    ],
    column_config={
        "Выбрать условие": st.column_config.CheckboxColumn(
            "Выбрать условие",
            help="Выбрать условие для редактирования",
        )
    },
)
tab1.button("Удалить условие", on_click=delete_lines)
tab1.button("Редактировать условие", on_click=edit_condition)

tab1.markdown("### Добавить условие")

# Не учитывать элементы
tab1.markdown("###### Не учитывать элементы")
ignore_elements = tab1.selectbox(
    "Не учитывать элементы",
    options=["менее 1%"],  # "менее 0,5 % и более 0,99%"
    key="ignore_elements",
    label_visibility="hidden",
)
# Коррозинно активные элементы
tab1.markdown("###### Коррозинно активные элементы")

corrosively_active_elements = tab1.multiselect(
    "Коррозинно активные элементы", options=config.elements, label_visibility="hidden"
)
# Содержание в спектре
tab1.markdown("###### Содержание в спектре")
difficult_condition = tab1.toggle("Сложное условие")
if st.session_state.ignore_elements == "менее 1%":
    min_value = 1.0
    max_value = None
else:
    min_value = 0.5
    max_value = 0.99
if difficult_condition:
    content_spectrum_all = tab1.number_input(
        "Каждый из элементов", min_value=min_value, max_value=max_value
    )
    tab1.text("или")
    col1, col2 = tab1.columns(2)
    content_spectrum_2_3 = col1.number_input(
        "Два из трех", min_value=min_value, max_value=max_value
    )
    content_spectrum_3 = col2.number_input(
        "Третий", min_value=min_value, max_value=max_value
    )
    content_spectrum = f">={content_spectrum_all}% каждый из элементов или >={content_spectrum_2_3}% два из трех и >={content_spectrum_3}% третий"
else:
    content_spectrum = tab1.number_input(
        "Каждый из элементов", min_value=min_value, max_value=max_value
    )

# Количество спекторов
tab1.markdown("###### Количество спекторов")

number_spectra = tab1.number_input("Количество спекторов", label_visibility="hidden")
# Совместное нахождение
tab1.markdown("###### Совместное нахождение")

joint_finding = tab1.multiselect(
    "Совместное нахождение", options=config.elements, label_visibility="hidden"
)

# Условия совместного нахождения
tab1.markdown("###### Условия совместного нахождения")

tab1.text("Условия совместного нахождения")
conditions_joint_residence = tab1.selectbox(
    "Условия совместного нахождения",
    options=[
        ">1% одном спектре не совместно",
        "любые в любом сочетании >=1%",
        "основные >1%, остальные <1%",  # Новая опция
        "один элемент 1-5% без других >1%",  # Новая опция
        "Нет условия",
    ],
    label_visibility="hidden",
)
# Место возникновения
tab1.markdown("###### Место возникновения")
tab1.button("Добавить место возникновения", on_click=vote)

place_origin = tab1.selectbox(
    "Место возникновения",
    st.session_state.all_places_of_origin,
    label_visibility="hidden",
)

tab1.button(
    "Добавить условие",
    on_click=add_condition,
    args=(
        False,
        ignore_elements,
        corrosively_active_elements,
        difficult_condition,
        content_spectrum,
        number_spectra,
        joint_finding,
        conditions_joint_residence,
        place_origin,
    ),
)


def add_final_result(*args):
    columns = ["places_occurrence", "final_result"]
    places_occurrence = args[0]
    final_result = args[1]
    
    # Если выбрано 3 и более мест, автоматически устанавливаем "На экспертизу"
    if len(places_occurrence) >= 3:
        final_result = "На экспертизу"
    
    # Преобразуем места в отсортированную строку
    places_sorted = sorted(places_occurrence)
    places_str = ",".join(places_sorted)
    
    # Проверяем, есть ли уже правило для этих мест
    session = Session()
    existing_result = crud.get_final_result(session, places_str)
    session.close()
    
    if existing_result:
        tab2.error(f"Такое условие уже существует: {existing_result}")
        return
    
    data = {
        "places_occurrence": places_str,
        "final_result": final_result
    }
    
    if len(places_str) == 0 or len(final_result) == 0:
        tab2.error("Укажите условия")
        return
    
    session = Session()
    result = crud.create_final_result(session, data)
    session.close()
    
    if result and "error" in result:
        tab2.error(f"Ошибка создания правила: {result['error']}")
    else:
        load_data()
        tab2.success("Правило успешно добавлено!")


# Итог
st.session_state.final_result_all_new = tab2.data_editor(
    st.session_state.final_result_all,
    disabled=["id", "Места возникновения", "Итоговый результат"],
    column_config={
        "Выбрать": st.column_config.CheckboxColumn(
            "Выбрать",
            help="Выбрать условие для редактирования",
        )
    },
)
tab2.button(
    "Удалить условие",
    on_click=delete_lines_final_result,
    key="tab2_button_delete_lines_final_result",
)

# Добавляем специальную опцию "3 и более"
all_places_with_option = st.session_state.all_places_of_origin + ["3 и более"]

# Выбор мест возникновения
places_occurrence = tab2.multiselect(
    "Выберете места возникновения", 
    all_places_with_option,
    key="places_occurrence"
)

# Определение итогового результата
if "3 и более" in places_occurrence:
    # Если выбрана опция "3 и более", автоматически устанавливаем "На экспертизу"
    final_result_value = "На экспертизу"
    # Показываем предупреждение
    tab2.warning("При выборе '3 и более' итоговый результат автоматически устанавливается в 'На экспертизу'")
else:
    # Иначе выбираем из обычных мест
    final_result_value = tab2.selectbox(
        "Итоговый результат", 
        places_occurrence if places_occurrence else [""],
        key="final_result"
    )

# Кнопка добавления правила
tab2.button(
    "Добавить условие",
    on_click=add_final_result,
    args=(places_occurrence, final_result_value),
    key="tab2_button_add_final_result",
)
