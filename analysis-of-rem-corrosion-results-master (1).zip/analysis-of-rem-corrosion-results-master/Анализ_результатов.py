import streamlit as st


from src.pdf2df import read_pdf, save_to_excel_tab1
from src.TableHandler import TableHandler, ConditionLess1, ConditionDifficultCondition
from src.postgresql import crud
import pandas as pd

from main import Session


def load_data():
    session = Session()
    st.session_state.data_all = pd.DataFrame(crud.get_all_analysis_with_places(session))
    session.close()


st.set_page_config(page_title="Анализ результатов РЭМ по коррозии", layout="wide")
st.title("Анализ результатов РЭМ по коррозии")


st.header("Загрузка файла")
uploaded_file = st.file_uploader("Выберите файл", type="pdf")
load_data()
all_conditions = []
for index, condition in st.session_state.data_all.iterrows():
    if condition["Не учитывать элементы"] == "менее 1%":
        if condition["Сложное условие"]:
            all_conditions.append(ConditionDifficultCondition(condition))
        else:
            all_conditions.append(ConditionLess1(condition))
result_df = {"Таблица": [], "Идентификатор": [], "Итоговый результат": []}
result_tabs = []
if uploaded_file:
    st.session_state.file_name = uploaded_file.name.split(".pdf")[0]
    st.session_state.tables, st.session_state.extracted_data = read_pdf(uploaded_file)
if "tables" in st.session_state:
    st.success("Файл успешно загружен.")
    for i, df in enumerate(st.session_state.tables):
        st.subheader(f"Таблица {st.session_state.extracted_data[i]}:")
        pr_df = TableHandler(df)
        if pr_df.not_empty:
            pr_df.analysis(all_conditions)
        else:
            st.markdown("Таблица содержит только **C, O, Fe**.")
        st.dataframe(pr_df.df_style)
        st.markdown(f"Итог: {pr_df.result}")
        result_df["Таблица"].append(i + 1)
        result_df["Идентификатор"].append(st.session_state.extracted_data[i])
        result_df["Итоговый результат"].append(pr_df.result)
        result_tabs.append(pr_df.df_style)
    st.markdown(f"## Общий итог")
    result_df = pd.DataFrame(data=result_df)
    st.dataframe(result_df)
    st.download_button(
        label="Скачать Excel-файл",
        data=save_to_excel_tab1(
            result_tabs, result_df, st.session_state.extracted_data
        ),
        file_name=f"{st.session_state.file_name}.xlsx",
    )
