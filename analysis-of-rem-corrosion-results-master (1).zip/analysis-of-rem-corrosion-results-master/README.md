
#Анализ результатов РЭМ по коррозии

DNS:
Тест: <https://analysis-of-rem-corrosion-results-test.kube.severstal.severstalgroup.com/>

Прод: <https://analysis-of-rem-corrosion-results.kube.severstal.severstalgroup.com/>
