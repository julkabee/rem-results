from src.postgresql.db import *
from sqlalchemy.orm import Session
from typing import List, Dict, Optional


def delete_condition(session, id):
    try:
        # Находим строку в таблице Conditions по заданному ID
        condition = session.query(Conditions).filter_by(id=id).first()

        # Если строка найдена, удаляем ее
        if condition:
            session.delete(condition)
            session.commit()
            return True
        else:
            return False
    except Exception as e:
        # Если возникает ошибка, откатываем изменения и возвращаем False
        session.rollback()
        print(f"Ошибка удаления условия: {e}")
        return False


def get_all_places_of_origin(session: Session) -> List[str]:
    """
    Получает все места происхождения из таблицы Place.

    Args:
        session: SQLAlchemy сессия для работы с БД

    Returns:
        List[str]: Список всех мест происхождения
    """
    try:
        # Запрашиваем все записи из таблицы Place и получаем только колонку place_of_origin
        places = session.query(Place.place_of_origin).all()
        # Преобразуем результат в список строк
        # places - это список кортежей, поэтому используем генератор списка для извлечения первого элемента
        return [place[0] for place in places]

    except Exception as e:
        print(f"Ошибка при получении мест происхождения: {str(e)}")
        return []


def get_all_analysis_with_places(session: Session) -> List[Dict]:
    """
    Получает все данные из таблицы Conditions вместе с соответствующими place_of_origin из Place

    Args:
        session: SQLAlchemy сессия

    Returns:
        List[Dict]: Список словарей с данными
    """
    try:
        # Используем join для объединения таблиц
        results = (
            session.query(Conditions, Place.place_of_origin)
            .join(Place, Conditions.id_place == Place.id)
            .all()
        )

        # Преобразуем результаты в список словарей
        analysis_list = []
        for conditions, place_of_origin in results:
            analysis_dict = {
                "id": conditions.id,
                "Выбрать": conditions.select_condition,
                "Не учитывать элементы": conditions.ignore_elements,
                "Коррозинно активные элементы": conditions.corrosive_active_elements,
                "Сложное условие": conditions.difficult_condition,
                "Содержание в спектре": conditions.content_in_spectrum,
                "Количество спекторов": conditions.number_of_spectors,
                "Совместное нахождение": conditions.joint_finding,
                "Условия совместного нахождения": conditions.conditions_of_joint_residence,
                "Место возникновения": place_of_origin,
            }
            analysis_list.append(analysis_dict)
        return analysis_list

    except Exception as e:
        print(f"Ошибка при получении данных: {str(e)}")
        return []


def create_analysis_with_place(session: Session, data) -> Optional[Dict]:
    """
    Создает новую запись в таблице Conditions с привязкой к Place
    """
    try:
        # Сначала проверяем, существует ли уже такое место
        place = (
            session.query(Place)
            .filter(Place.place_of_origin == data["place_of_origin"])
            .first()
        )
        # Если места нет, создаем новое
        if not place:
            place = Place(place_of_origin=data["place_of_origin"])
            session.add(place)
            session.flush()

        # Создаем новую запись в Conditions
        new_conditions = Conditions(
            select_condition=data["select_condition"],
            ignore_elements=data["ignore_elements"],
            corrosive_active_elements=data["corrosive_active_elements"],
            difficult_condition=data["difficult_condition"],
            content_in_spectrum=data["content_in_spectrum"],
            number_of_spectors=data["number_of_spectors"],
            joint_finding=data["joint_finding"],
            conditions_of_joint_residence=data["conditions_of_joint_residence"],
            id_place=place.id,
        )

        session.add(new_conditions)
        session.commit()

        # Возвращаем созданную запись в виде словаря
        return True

    except Exception as e:
        session.rollback()
        print(f"Ошибка при создании записи: {str(e)}")
        return None


def create_place(session: Session, place_of_origin: str) -> Optional[Place]:
    """Создает новую запись о месте происхождения"""
    try:
        new_place = Place(place_of_origin=place_of_origin)
        session.add(new_place)
        session.commit()
        return new_place
    except Exception as e:
        session.rollback()
        print(f"Ошибка при создании места: {str(e)}")
        return None


def create_final_result(session, data):
    try:
        # Создаем новый объект FinalResult
        new_final_result = FinalResult(
            places_occurrence=data["places_occurrence"],
            final_result=data["final_result"],
        )

        # Добавляем объект в сессию
        session.add(new_final_result)

        # Сохраняем изменения в базе данных
        session.commit()

        return {
            "message": "Final result successfully created",
            "id": new_final_result.id,
        }

    except Exception as e:
        # Если произошла ошибка, откатываем изменения
        session.rollback()
        return {"error": str(e)}


def get_all_final_results(session: Session) -> List[Dict]:
    """
    Получает все данные из таблицы FinalResult

    Args:
        session: SQLAlchemy сессия

    Returns:
        List[Dict]: Список словарей с данными
    """
    try:
        # Используем query для получения всех записей из таблицы
        results = session.query(FinalResult).all()

        # Преобразуем результаты в список словарей
        final_results_list = []
        for final_result in results:
            final_result_dict = {
                "id": final_result.id,
                "Выбрать": 0,
                "Места возникновения": final_result.places_occurrence,
                "Итоговый результат": final_result.final_result,
            }
            final_results_list.append(final_result_dict)
        if len(final_results_list) == 0:
            final_results_list = [
                {
                    "id": 1,
                    "Выбрать": 0,
                    "Места возникновения": None,
                    "Итоговый результат": None,
                }
            ]
        return final_results_list

    except Exception as e:
        print(f"Ошибка при получении данных: {str(e)}")
        return []


def delete_final_result(session: Session, id: int) -> None:
    """
    Удаляет запись из таблицы FinalResult по ID

    Args:
        session: SQLAlchemy сессия
        id: ID записи для удаления
    """
    try:
        # Используем query для получения записи по ID
        final_result = session.query(FinalResult).filter(FinalResult.id == id).first()

        # Если запись найдена, удаляем её
        if final_result:
            session.delete(final_result)
            session.commit()
        else:
            print(f"Запись с ID {id} не найдена")

    except Exception as e:
        print(f"Ошибка при удалении записи: {str(e)}")


def get_final_result(session: Session, places_occurrence: str) -> str:
    """
    Получает final_result из таблицы FinalResult по places_occurrence

    Args:
        session: SQLAlchemy сессия
        places_occurrence: places_occurrence для поиска

    Returns:
        str: final_result если запись найдена, None в противном случае
    """
    try:
        # Используем query для получения записи по places_occurrence
        final_result = (
            session.query(FinalResult)
            .filter(FinalResult.places_occurrence == places_occurrence)
            .first()
        )

        # Если запись найдена, возвращаем final_result
        if final_result:
            return final_result.final_result
        else:
            return None

    except Exception as e:
        print(f"Ошибка при получении данных: {str(e)}")
        return None


def update_conditions(session: Session, data: dict):
    """
    Обновляет запись в таблице Conditions на основе предоставленных данных.
    """
    try:
        condition_id = data.get("id")
        if not condition_id:
            raise ValueError("ID условия не предоставлен.")

        # fix
        condition_id = int(condition_id)

        condition = (
            session.query(Conditions).filter(Conditions.id == condition_id).first()
        )

        if not condition:
            raise ValueError(f"Условие с ID {condition_id} не найдено.")

        for key, value in data.items():
            if key != "id" and key != "place_of_origin":
                setattr(condition, key, value)

        place_of_origin = data.get("place_of_origin")
        if place_of_origin:
            place = (
                session.query(Place)
                .filter(Place.place_of_origin == place_of_origin)
                .first()
            )
            if place:
                condition.id_place = place.id
            else:
                new_place = Place(place_of_origin=place_of_origin)
                session.add(new_place)
                session.flush()
                condition.id_place = new_place.id

        session.commit()

    except Exception as e:
        session.rollback()
        raise e
