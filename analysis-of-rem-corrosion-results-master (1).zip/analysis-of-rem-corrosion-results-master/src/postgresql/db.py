from sqlalchemy import create_engine, Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()


class Conditions(Base):
    __tablename__ = "conditions"
    __table_args__ = {"schema": "analysis_of_REM"}

    id = Column(Integer, primary_key=True, autoincrement=True)
    select_condition = Column(Boolean)
    ignore_elements = Column(String)
    corrosive_active_elements = Column(String)
    difficult_condition = Column(Boolean)
    content_in_spectrum = Column(String)
    number_of_spectors = Column(Integer)
    joint_finding = Column(String)
    conditions_of_joint_residence = Column(String)
    id_place = Column(Integer, ForeignKey("analysis_of_REM.place.id"))

    # Создаем отношение с таблицей Place
    place = relationship("Place")


class Place(Base):
    __tablename__ = "place"
    __table_args__ = {"schema": "analysis_of_REM"}

    id = Column(Integer, primary_key=True, autoincrement=True)
    place_of_origin = Column(String, nullable=False)


class FinalResult(Base):
    __tablename__ = "final_result"
    __table_args__ = {"schema": "analysis_of_REM"}

    id = Column(Integer, primary_key=True, autoincrement=True)
    places_occurrence = Column(String, nullable=False)
    final_result = Column(String, nullable=False)
