import pandas as pd
import streamlit as st
import ast
import re
from src.config import Configuration
from src.postgresql import crud
from main import Session


def highlight_greater_than_one(val):
    """
    Функция для подсветки ячеек с значениями больше 1.
    """
    if type(val) == float:
        if val > 1:
            return "background-color: yellow"


class ConditionLess1:
    def __init__(self, condition) -> None:
        self.threshold = 1
        self.corrosively_active_elements = condition[
            "Коррозинно активные элементы"
        ].split(",")

        self.content_spectrum = int(condition["Содержание в спектре"].split(".")[0])
        self.number_spectra = int(condition["Количество спекторов"])
        self.joint_finding = condition["Совместное нахождение"].split(",")

        self.conditions_joint_residence = str(
            condition["Условия совместного нахождения"]
        )
        self.place_origin = condition["Место возникновения"]

    def elements_not_included(self, spectrum):
        for element in self.corrosively_active_elements:
            if not (
                element in spectrum.spectrum
                and spectrum.spectrum[element] > self.content_spectrum
            ):
                return True

        return False

    def check_condition(self, spectrum):
        if self.elements_not_included(spectrum):
            return False
            
        spectrum_element = spectrum.get_elements(
            self.threshold, self.corrosively_active_elements
        )
        
        if (
            self.conditions_joint_residence == ">1% одном спектре не совместно"
            and len(spectrum_element) == 0
        ):
            return True
        elif (
            self.conditions_joint_residence == "любые в любом сочетании >=1%"
            and len(spectrum_element) != 0
            and set(spectrum_element).issubset(self.joint_finding)
        ):
            return True
        elif (
            self.conditions_joint_residence == "основные >1%, остальные <1%"
        ):
            additional_elements_valid = True
            for element in self.joint_finding:
                if element in spectrum.spectrum and spectrum.spectrum[element] >= 1:
                    additional_elements_valid = False
                    break
            return additional_elements_valid
        # Новое условие: один элемент 1-5% без других >1%
        elif (
            self.conditions_joint_residence == "один элемент 1-5% без других >1%"
        ):
            # Проверяем, что есть ровно один элемент из списка в диапазоне 1-5%
            count_in_range = 0
            found_element = None
            for element in self.corrosively_active_elements:
                if element in spectrum.spectrum:
                    value = spectrum.spectrum[element]
                    if 1 <= value <= 5:
                        count_in_range += 1
                        found_element = element
            
            # Если нашли ровно один такой элемент
            if count_in_range != 1:
                return False
                
            # Проверяем, что нет других элементов >1%
            for element, value in spectrum.spectrum.items():
                if element == found_element:
                    continue
                if value > 1:
                    return False
                    
            return True
        
        return False


class ConditionDifficultCondition(ConditionLess1):
    def __init__(self, condition) -> None:
        self.threshold = 1
        self.corrosively_active_elements = condition[
            "Коррозинно активные элементы"
        ].split(",")

        self.content_spectrum = [
            float(num)
            for num in re.findall(
                r">=(\d+(?:\.\d+)?)", condition["Содержание в спектре"]
            )
        ]
        self.number_spectra = int(condition["Количество спекторов"])
        self.joint_finding = condition["Совместное нахождение"].split(",")

        self.conditions_joint_residence = str(
            condition["Условия совместного нахождения"]
        )
        self.place_origin = condition["Место возникновения"]

    def elements_not_included(self, spectrum):
        for element in self.corrosively_active_elements:
            if not (element in spectrum.spectrum):
                return True
        
        var1 = spectrum.spectrum[self.corrosively_active_elements[0]]
        var2 = spectrum.spectrum[self.corrosively_active_elements[1]]
        var3 = spectrum.spectrum[self.corrosively_active_elements[2]]
        threshold1 = self.content_spectrum[0]
        threshold2 = self.content_spectrum[1]
        threshold3 = self.content_spectrum[2]
        
        if var1 > threshold1 and var2 > threshold1 and var3 > threshold1:
            return False

        if ((var1 > threshold2 and var2 > threshold2) or
            (var1 > threshold2 and var3 > threshold2) or
            (var2 > threshold2 and var3 > threshold2)) and var3 > threshold3:
            return False
            
        return True

    def check_condition(self, spectrum):
        if self.elements_not_included(spectrum):
            return False
            
        if self.conditions_joint_residence == "основные >1%, остальные <1%":
            additional_elements_valid = True
            for element in self.joint_finding:
                if element in spectrum.spectrum and spectrum.spectrum[element] >= 1:
                    additional_elements_valid = False
                    break
            return additional_elements_valid
        # Новое условие: один элемент 1-5% без других >1%
        elif (
            self.conditions_joint_residence == "один элемент 1-5% без других >1%"
        ):
            # Проверяем, что есть ровно один элемент из списка в диапазоне 1-5%
            count_in_range = 0
            found_element = None
            for element in self.corrosively_active_elements:
                if element in spectrum.spectrum:
                    value = spectrum.spectrum[element]
                    if 1 <= value <= 5:
                        count_in_range += 1
                        found_element = element
            
            # Если нашли ровно один такой элемент
            if count_in_range != 1:
                return False
                
            # Проверяем, что нет других элементов >1%
            for element, value in spectrum.spectrum.items():
                if element == found_element:
                    continue
                if value > 1:
                    return False
                    
            return True
            
        spectrum_element = spectrum.get_elements(
            self.threshold, self.corrosively_active_elements
        )
        
        if (
            self.conditions_joint_residence == ">1% одном спектре не совместно"
            and len(spectrum_element) == 0
        ):
            return True
        elif (
            self.conditions_joint_residence == "любые в любом сочетании >=1%"
            and len(spectrum_element) != 0
            and set(spectrum_element).issubset(self.joint_finding)
        ):
            return True
            
        return False


class TableHandler:
    def __init__(self, df: pd.DataFrame) -> None:
        self.elements_to_remove: list = ["C", "O", "Fe", "В стат.", "Итог"]
        self.df_all = df.copy().set_index("Спектр")
        self.df_all["Место возникновения"] = ""
        self.df: pd.DataFrame = self.filter_df(df)
        self.format_float = dict.fromkeys(
            self.df_all.select_dtypes("float").columns, "{:.5}"
        )
        self.elements: list = list(self.df)
        self.spectrums: list = []
        self.rows_to_color: list = []
        if self.not_empty:
            self.creating_spectra()

    def filter_df(self, df: pd.DataFrame):
        df = df.set_index("Спектр")
        df = df.drop(columns=self.elements_to_remove, errors="ignore")
        df.dropna(how="all", inplace=True)
        df.dropna(axis="columns", how="all", inplace=True)
        if len(df) == 0:
            self.not_empty = False
            self.df_all["Место возникновения"] = "Нет концентратора"
            self.df_style = self.df_all.copy(True)
            self.result = "Нет концентратора"
        else:
            self.not_empty = True
        return df

    def creating_spectra(self):
        for name, spect in self.df.iterrows():
            self.spectrums.append(Spectrum(name, spect))
            
    def check_condition_with_ignore(self, spectrum, condition):
        """
        Проверяет, может ли условие выполняться при игнорировании одного элемента
        """
        # Находим элементы >1% в этом спектре
        elements_above_1 = []
        for element, value in spectrum.spectrum.items():
            if isinstance(value, (int, float)) and value > 1:
                elements_above_1.append(element)
        
        # Пробуем игнорировать каждый элемент >1% по очереди
        for element_to_ignore in elements_above_1:
            # Создаем копию спектра без игнорируемого элемента
            modified_spectrum = Spectrum(spectrum.name, pd.Series(spectrum.spectrum.copy()))
            if element_to_ignore in modified_spectrum.spectrum:
                del modified_spectrum.spectrum[element_to_ignore]
            
            # Проверяем условие на модифицированном спектре
            if condition.check_condition(modified_spectrum):
                return True, element_to_ignore
                    
        return False, None

    def analysis(self, all_conditions: list[ConditionLess1]):
        result = {}
        # Словарь для хранения игнорируемых элементов
        ignored_elements = {}
        
        # Первый проход: проверяем условия без изменений
        for condition in all_conditions:
            for spectrum in self.spectrums:
                if self.df_all.loc[spectrum.name, "Место возникновения"] != "":
                    continue
                    
                if condition.check_condition(spectrum):
                    self.df_all.loc[spectrum.name, "Место возникновения"] = condition.place_origin
                    if spectrum.name not in self.rows_to_color:
                        self.rows_to_color.append(spectrum.name)

        # Второй проход: для спектров без места возникновения
        for spectrum in self.spectrums:
            if self.df_all.loc[spectrum.name, "Место возникновения"] != "":
                continue
                
            for condition in all_conditions:
                # Проверяем, может ли условие выполняться при игнорировании одного элемента
                condition_met, ignored_element = self.check_condition_with_ignore(spectrum, condition)
                if condition_met:
                    self.df_all.loc[spectrum.name, "Место возникновения"] = condition.place_origin
                    ignored_elements[spectrum.name] = ignored_element
                    if spectrum.name not in self.rows_to_color:
                        self.rows_to_color.append(spectrum.name)
                    break  # Переходим к следующему спектру

        # Третий проход: гарантируем, что все спектры получат место возникновения
        columns_to_process = [
            col
            for col in self.df_all.columns
            if col not in ["В стат.", "Место возникновения", "Итог", "C", "O", "Fe"]
        ]

        # Перебираем все строки в DataFrame
        for index in self.df_all.index:
            if self.df_all.loc[index, "Место возникновения"] == "":
                # Проверяем значения в столбцах для обработки
                row = self.df_all.loc[index]
                if any(row[col] > 1 for col in columns_to_process):
                    self.df_all.loc[index, "Место возникновения"] = "На экспертизу"
                else:
                    self.df_all.loc[index, "Место возникновения"] = "Нет концентратора"

        # Применяем стилизацию и замену значений только к нужным столбцам
        self.df_style = self.df_all.style.map(
            highlight_greater_than_one, subset=columns_to_process
        )

        self.df_style = self.df_style.apply(
            lambda x: [
                "background-color: red" if x.name in self.rows_to_color else ""
                for _ in x
            ],
            axis=1,
        )
        self.df_style = self.df_style.format(self.format_float)
        
        # Собираем все уникальные места возникновения (включая "На экспертизу")
        unique_places = []
        for index, row in self.df_all.iterrows():
            place = row["Место возникновения"]
            if place != "Нет концентратора" and place not in unique_places:
                unique_places.append(place)

        # Если 3 или более уникальных мест (включая "На экспертизу") - итог "На экспертизу"
        if len(unique_places) >= 3:
            self.result = "На экспертизу"
        elif len(unique_places) == 0:
            self.result = "Нет концентратора"
        elif len(unique_places) == 1:
            self.result = unique_places[0]
        else:  # 2 уникальных места
            data = ",".join(sorted(unique_places))
            session = Session()
            result_db = crud.get_final_result(session, data)
            session.close()
            if result_db is not None:
                self.result = result_db
            else:
                self.result = f"Правила нет ({data})"
                
        # Выводим информацию об игнорированных элементах
        # for spectrum_name, element in ignored_elements.items():
        #     st.info(f"Для спектра {spectrum_name} игнорирован элемент {element}")


class Spectrum:
    def __init__(self, name, spect) -> None:
        self.name: str = name
        self.spectrum = spect.dropna().to_dict()

    def get_elements(self, threshold, corrosively_active_elements):
        result = []
        for element in self.spectrum:
            if (
                self.spectrum[element] >= threshold
                and not element in corrosively_active_elements
            ):
                result.append(element)
        return result
