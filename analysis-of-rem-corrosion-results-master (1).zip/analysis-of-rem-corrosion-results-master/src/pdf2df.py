import tabula
import pandas as pd
import pdfplumber
import re
from io import BytesIO


def read_pdf(file):
    tables = tabula.read_pdf(file, pages="all")
    dataframes = []

    for i, table in enumerate(tables):
        df = pd.DataFrame(table)
        if df.columns[0] == 0:
            df.columns = df.iloc[0]
            df = df[1:]
        df.dropna(how="all", inplace=True)
        df = df.iloc[:-2]
        dataframes.append(df)
    # Регулярное выражение для поиска номера образца (всё после "Образец:")
    sample_regex = re.compile(r"Образец\s*:\s*(.+)")

    # Регулярное выражение для поиска строк с таблицей
    table_start_regex = re.compile(r"Спектр\s+В\s+стат\.")

    # Результаты для всех образцов
    extracted_data = []

    with pdfplumber.open(file) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                # Ищем номер образца на странице
                sample_match = sample_regex.search(text)
                if sample_match:
                    sample_number = sample_match.group(1).strip()  # Убираем пробелы
                    # Ищем начало таблицы
                    table_start_match = table_start_regex.search(text)
                    if table_start_match:
                        extracted_data.append(sample_number)
    return dataframes, extracted_data


def save_to_excel_tab1(dataframes, result_df, extracted_data):
    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        result_df.to_excel(writer, sheet_name="ИТОГ", index=False)
        for i, df in enumerate(dataframes):
            sheet_name = f"{i+1}_{extracted_data[i]}"
            df.to_excel(writer, sheet_name=sheet_name, index=False)
        output.seek(0)
        return output
