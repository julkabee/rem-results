from dataclasses import dataclass
import os


@dataclass
class Configuration:
    """Define project's configurable parameters."""

    HOST: str = os.environ.get("HOST")
    PORT: int = os.environ.get("PORT")
    USERNAME: str = os.environ.get("USERNAME")
    PASSWORD: str = os.environ.get("PASSWORD")
    PROD: bool = int(os.environ.get("PROD"))

    @property
    def engine(self) -> str:
        return f"postgresql://{self.USERNAME}:{self.PASSWORD}@{self.HOST}:{self.PORT}/{self.USERNAME}"


elements = [
    "N",
    "F",
    "Na",
    "Mg",
    "Al",
    "Si",
    "P",
    "S",
    "Cl",
    "K",
    "Ca",
    "Ti",
    "V",
    "Cr",
    "Mn",
    "Zn",
    "Cu",
    "Mo",
    "Ni",
    "Nb",
    "Br",
    "Zr",
    "Ba",
]
